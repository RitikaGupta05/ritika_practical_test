import React from 'react';

const Header = (props)  => {
  return (
    <footer>
    <a href="#">
      <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/25480/twitter-wrap.png" alt="Twitter Logo" className="social-icon" /></a>
    <a href="#">
      <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/25480/facebook-wrap.png" alt="Facebook Logo" className="social-icon" /></a>
    <p>&copy; 2021 Test.</p>
  </footer>
  );
}
 
export default Header;