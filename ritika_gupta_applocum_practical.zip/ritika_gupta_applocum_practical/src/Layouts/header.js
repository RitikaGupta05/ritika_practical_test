import React from 'react';

import Signup from './Signup';

let userid =  localStorage.getItem("userid");
const logout = () => {
	localStorage.clear();
	window.location.assign("/");
};

const Header = (props) => {
	return (
		<div>
			<header>
				<div className="container">
					<a href="#" id="logo"> logo</a>
					<nav>
						<ul>
							<li><a href="#" className="selected">Home</a></li>
							<li><a href="#">About</a></li>
							<li><a href="#">Contact</a></li>
				    <li>
				  	{!userid ? <a href="#">
								<button className="btn btn-primary btn-lg" href="#signup"
									data-toggle="modal" data-target=".log-sign">Signup/Register</button>
							</a>
							:
							<a  onClick={logout} >
								<button className="btn btn-primary btn-lg"	>Log Out</button>
							</a>
              }
							</li>

						</ul>
					</nav>
				</div>
			</header>

			{/* // <!-- Modal --> */}
			<div className="modal fade log-sign" id="myModal" tabIndex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
				<div className="modal-dialog">
					<div className="modal-content">

						
						<div className="modal-body">
							<div id="myTabContent" className="tab-content">
							<h2>Sign Up</h2>
								<div className="" id="signup">
									<Signup />
								</div>

							</div>
						</div>
					
					</div>
				</div>
			</div>
		</div>
	);
}

export default Header;