import React, { useState } from 'react';

function Login(props) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  async function login() {
    let item = { email, password }
    let result = await fetch("https://dev-api.alldaydr.com/api/users/sign_in.json", {
      method: 'POST', 
      mode: 'cors', 
      cache: 'no-cache', 
      credentials: 'same-origin',
      body: JSON.stringify(item),
      headers: {
        "Content-Type": 'application/json',
        "Accept": 'application/json'
      }
    });
    result = await result.json();
    console.log(result, "==result");
    localStorage.setItem("user-info",JSON.stringify(result));
  }

  return (
    <div id="myTabContent" className="logintab-content">
         <div className="tab-pane active in" id="signin">
             <h2 >Sign In Form</h2>
      <form className="form-horizontal">
        <fieldset>


          <div className="group">
            <input  required={true} className="input" type="text"
              onChange={(e) => setEmail(e.target.value)} />
            <span className="highlight"></span><span className="bar"></span>
            <label className="label" htmlFor="date">Email address</label></div>



          <div className="group">
            <input  required={true} className="input" type="password"
              onChange={(e) => setPassword(e.target.value)} />
            <span className="highlight"></span><span className="bar"></span>
            <label className="label" htmlFor="date">Password</label>
          </div>
          <em>minimum 6 characters</em>

          {/* <div className="forgot-link">
            <a href="#forgot" data-toggle="modal" data-target="#forgot-password"> I forgot my password</a>
          </div> */}


          <div className="control-group">
            <label className="control-label" htmlFor="signin"></label>
            <div className="controls">
              <button id="signin" name="signin" className="btn btn-primary btn-block"
                onClick={login}>Log In</button>
            </div>
          </div>
        </fieldset>
      </form>
      </div>
            </div>
  );
}


export default Login;