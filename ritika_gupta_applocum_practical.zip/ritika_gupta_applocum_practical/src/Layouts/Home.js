import React, { Fragment } from 'react';
import Login from './Login';
import Footer from './footer';
import Header from "./header";
import Dashboard from './Dashboard';

const HomeLayout = (props) => {


    return (
<Fragment>
        
        <Header />
       
          <Login />
           {/* <Dashboard /> */}
    
        <Footer />
       
    </Fragment>
    )
    
}




export default HomeLayout;