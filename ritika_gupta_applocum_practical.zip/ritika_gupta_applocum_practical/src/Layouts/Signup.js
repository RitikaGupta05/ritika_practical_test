import React, { useState } from 'react';

function Login(props) {
	const [first_name, setFirst_Name] = useState("");
	const [last_name, setLast_Name] = useState("");
	const [email, setEmail] = useState("");
	const [password,setPassword] = useState("");
    const [phone, setPhone] = ("")

 async function signUp(){
	let item = {first_name,last_name,email,password,phone}
	console.log(item,"==item");
	let result = await fetch("https://dev-api.alldaydr.com/api/users/sign_up.json",{
		method:'POST',
		body:JSON.stringify(item),
		headers:{
			"Content-Type":'application/json',
			"Accept" :'application/json'
		}
	});
	result = await result.json();
	console.log(result,"==result");
	localStorage.setItem("user-info",JSON.stringify(result));
}


	return (
		<div>
			<form className="form-horizontal">
				<fieldset>

					<div className="group">
						<input  required={true} className="input" type="text" 
						onChange={(e)=> setFirst_Name(e.target.value)} />
						<span className="highlight"></span><span className="bar"></span>
						<label className="label" htmlFor="date">First Name</label></div>


					<div className="group">
						<input  required={true} className="input" type="text" 
						onChange={(e)=> setLast_Name(e.target.value)} />
						<span className="highlight"></span><span className="bar"></span>
						<label className="label" htmlFor="date">Last Name</label></div>


					<div className="group">
						<input  required={true} className="input" type="text" 
						onChange={(e)=> setEmail(e.target.value)} />
						<span className="highlight"></span><span className="bar"></span>
						<label className="label" htmlFor="date">Email</label></div>

						<div className="group">
						<input  required={true} className="input" type="number" 
						onChange={(e)=> setPhone(e.target.value)} />
						<span className="highlight"></span><span className="bar"></span>
						<label className="label" htmlFor="date">Phone</label></div>

					<div className="group">
						<input  required={true} className="input" type="password" 
						onChange={(e)=> setPassword(e.target.value)} />
						<span className="highlight"></span><span className="bar"></span>
						<label className="label" htmlFor="date">Password</label></div>
					<em>1-8 Characters</em>

						<div className="control-group">
						<label className="control-label" htmlFor="confirmsignup"></label>
						<div className="controls">
							<button id="confirmsignup" name="confirmsignup" className="btn btn-primary btn-block"
							onClick={signUp}>Sign Up</button>
						</div>
					</div>
				</fieldset>
			</form>
		</div>
	);
}


export default Login;