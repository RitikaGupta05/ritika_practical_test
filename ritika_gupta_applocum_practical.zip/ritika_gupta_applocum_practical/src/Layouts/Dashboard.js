import React from 'react';

const Dashboard = (props) => {

  const products = [
    {
      Name: "Cheese",
      price: '2.50',
      location: 'Refrigerated foods',
      qty: '2'
    },
    {
      Name: "Crisps",
      price: '4',
      location: 'The Snacks lays',
      qty: '2'
    },
    {
      Name: "Burgur",
      price: '5',
      location: 'Refrigerated foods',
      qty: '4'
    },
    {
      Name: "Pizza",
      price: '7',
      location: 'Refrigerated foods',
      qty: '6'
    }
  ];

  return (
    <div>

      <div id="wrapper">
        <section>
          <ul id="gallery">
            {products.map((record, index) => (
              <li>
                <a href="#">
                  <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/25480/numbers-01.jpg" alt="" />
                 <div >
                 <p> {record.Name}
                  <span style={{float: "right"}}>Rs.{record.price}</span>
                  </p>
                  <p>{record.location}</p>
                 </div>
                  <button>Add To Cart</button>

                </a>
              </li>

            ))}
          </ul>
        </section>

      </div>
    </div>
  );
}

export default Dashboard;